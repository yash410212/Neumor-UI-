# Modern Launcher — Tecno Spark 8C + vivo Y11 Performance Polish

This build is tuned for the Tecno Spark 8C (KG5K) and vivo Y11 (2019) without cutting animation quality.

## Full animation preserved
- **No Lite animation mode.**
- Spring animation remains the default.
- Default animation smoothness remains **70%**.
- Default duration remains **500 ms**.
- Pager keeps one adjacent page composed for fluid swiping.
- Drag/drop keeps lift, finger-follow, spring reorder and settle motion.
- Blur/widgets are not forcibly disabled; their state is controlled by the user's settings.

## Efficiency improvements without reducing motion
- Device-aware profile is used for implementation choices, not reduced animation settings.
- Installed app icons are cached to avoid repeated PackageManager work during recomposition.
- Icon bitmap cache target increased to 96 px for better icon sharpness while remaining bounded.
- Existing Compose spring animations remain intact.
- Pager composition remains responsive for smooth page transitions.
- HOME/launcher behavior, folders, widgets, app drawer and persistent state are retained.

## Device targets
- **Tecno Spark 8C / KG5K:** 720×1612 HD+ class.
- **vivo Y11 (2019):** 720×1544 HD+ class.

## Android
- Minimum Android 8 / API 26.
- Compile/target API 35.
- JVM 17.

The project was not device-built here because this environment does not contain a complete Android SDK/Gradle distribution.
