package com.example.modernlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.ActivityManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.app.role.RoleManager
import android.os.Build
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.runtime.composed
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import java.util.concurrent.ConcurrentHashMap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

enum class GridMode(val columns: Int, val rows: Int, val title: String) { THREE_BY_FOUR(3,4,"3×4"), FIVE_BY_FOUR(5,4,"5×4"), FIVE_BY_SIX(5,6,"5×6") }
enum class IconSize(val title:String,val dp:Int){ SMALL("Small",46),MEDIUM("Medium",52),LARGE("Large",60) }
enum class IconShape(val title:String){ CIRCLE("Circle"),ROUNDED("Rounded"),SQUARE("Square") }
enum class AnimationType(val title:String){ SPRING("Spring"),FADE("Fade"),SLIDE("Slide"),SCALE("Scale") }
enum class PerformanceMode(val title:String,val subtitle:String){ HIGH("High Performance","Maximum rendering responsiveness"), LITE("Lite Performance","Lower memory and rendering load") }

data class LauncherApp(
    val id:String,
    val label:String,
    val packageName:String? = null,
    val activityName:String? = null,
    val isLauncherSettings:Boolean = false,
    val isFolder:Boolean = false,
    val folderItems:List<LauncherApp> = emptyList()
)

data class HomeWidgetRecord(
    val appWidgetId: Int,
    val page: Int,
    val spanX: Int = 2,
    val spanY: Int = 2
)


class LauncherViewModel: androidx.lifecycle.ViewModel(){
    var gridMode by mutableStateOf(GridMode.FIVE_BY_FOUR); private set
    var darkMode by mutableStateOf(false); private set
    var iconSize by mutableStateOf(IconSize.MEDIUM); private set
    var iconShape by mutableStateOf(IconShape.ROUNDED); private set
    var animationValue by mutableFloatStateOf(70f); private set
    var animationDuration by mutableFloatStateOf(500f); private set
    var animationType by mutableStateOf(AnimationType.SPRING); private set
    var widgetsEnabled by mutableStateOf(true); private set
    var gesturesEnabled by mutableStateOf(true); private set
    var foldersEnabled by mutableStateOf(true); private set
    var appSuggestionsEnabled by mutableStateOf(false); private set
    var edgePanelEnabled by mutableStateOf(false); private set
    var blurEnabled by mutableStateOf(true); private set
    var settingsOpen by mutableStateOf(false); private set
    var settingsPage by mutableStateOf("main"); private set
    var appDrawerOpen by mutableStateOf(false); private set
    var openFolderId by mutableStateOf<String?>(null); private set
    var folderRenameId by mutableStateOf<String?>(null); private set
    var appSearch by mutableStateOf(""); private set
    var drawerListMode by mutableStateOf(false); private set
    var drawerCategory by mutableStateOf("All"); private set
    var recentAppIds by mutableStateOf<List<String>>(emptyList()); private set
    var installedApps by mutableStateOf<List<LauncherApp>>(emptyList()); private set
    var pages by mutableStateOf<List<List<LauncherApp>>>(emptyList()); private set
    private var prefs:android.content.SharedPreferences?=null
    var homeWidgets by mutableStateOf<List<HomeWidgetRecord>>(emptyList()); private set
    var currentHomePage by mutableIntStateOf(0); private set
    var performanceProfile by mutableStateOf("Balanced"); private set
    var lowRamDevice by mutableStateOf(false); private set
    var performanceMode by mutableStateOf(PerformanceMode.HIGH); private set
    var wallpaperUri by mutableStateOf<String?>(null); private set
    var productiveMode by mutableStateOf(false); private set
    var studyMode by mutableStateOf(false); private set
    var studySelectedIds by mutableStateOf<Set<String>>(emptySet()); private set

    private fun applyDeviceProfile(context: Context) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        lowRamDevice = am?.isLowRamDevice == true || Build.VERSION.SDK_INT <= Build.VERSION_CODES.O_MR1
        val manufacturer = Build.MANUFACTURER.lowercase(Locale.US)
        val model = Build.MODEL.lowercase(Locale.US)
        val spark8c = manufacturer.contains("tecno") && (model.contains("kg5k") || model.contains("spark 8c"))
        val vivoY11 = manufacturer.contains("vivo") && (model.contains("1906") || model.contains("y11"))
        // Device-aware tuning changes rendering efficiency, not the visual animation quality.
        // Spark 8C / vivo Y11 keep the full animation profile; low-RAM detection is used only
        // for memory-safe implementation details such as caching and pager composition.
        performanceProfile = when {
            spark8c -> "Spark8C-Full"
            vivoY11 -> "VivoY11-Full"
            lowRamDevice -> "LowRam-Full"
            else -> "Balanced-Full"
        }
    }

    fun init(context:Context){
        if(prefs!=null) return
        prefs=context.getSharedPreferences("launcher_settings",Context.MODE_PRIVATE)
        val p=prefs!!
        applyDeviceProfile(context)
        gridMode=GridMode.values().getOrElse(p.getInt("grid",1)){GridMode.FIVE_BY_FOUR}
        darkMode=p.getBoolean("dark",false)
        iconSize=IconSize.values().getOrElse(p.getInt("iconSize",1)){IconSize.MEDIUM}
        iconShape=IconShape.values().getOrElse(p.getInt("iconShape",1)){IconShape.ROUNDED}
        // Preserve the full smooth animation defaults on both target phones.
        animationValue=p.getFloat("animValue", 70f); animationDuration=p.getFloat("animDuration", 500f)
        animationType=AnimationType.values().getOrElse(p.getInt("animType",0)){AnimationType.SPRING}
        performanceMode=PerformanceMode.values().getOrElse(p.getInt("performanceMode",0)){PerformanceMode.HIGH}; CURRENT_PERFORMANCE_MODE=performanceMode
        wallpaperUri=p.getString("wallpaperUri",null)
        productiveMode=p.getBoolean("productiveMode",false)
        studyMode=p.getBoolean("studyMode",false)
        studySelectedIds=p.getString("studySelectedIds","").orEmpty().split("|").filter{it.isNotBlank()}.toSet()
        widgetsEnabled=p.getBoolean("widgets", true); gesturesEnabled=p.getBoolean("gestures",true); foldersEnabled=p.getBoolean("folders",true)
        appSuggestionsEnabled=p.getBoolean("suggestions",false); edgePanelEnabled=p.getBoolean("edge",false); blurEnabled=p.getBoolean("blur",true)
        recentAppIds=p.getString("recent_apps", "").orEmpty().split("|").filter { it.isNotBlank() }
        homeWidgets = decodeWidgets(p.getString("widgets_home", ""))
        currentHomePage = p.getInt("current_page", 0).coerceAtLeast(0)
        refreshApps(context)
    }

    fun refreshApps(context:Context){
        val pm=context.packageManager
        val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list=pm.queryIntentActivities(intent,PackageManager.MATCH_ALL)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .map { r -> LauncherApp(
                id="${r.activityInfo.packageName}/${r.activityInfo.name}",
                label=r.loadLabel(pm)?.toString()?.trim().orEmpty().ifEmpty { r.activityInfo.packageName },
                packageName=r.activityInfo.packageName,
                activityName=r.activityInfo.name
            ) }
            .distinctBy { it.id }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .toList()
        installedApps=list
        rebuildPages()
    }

    private fun encode(value:String):String = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
    private fun decode(value:String):String = try { String(Base64.decode(value, Base64.NO_WRAP or Base64.URL_SAFE), Charsets.UTF_8) } catch (_:Exception) { "" }

    private fun rebuildPages(){
        val pageCapacity=(gridMode.columns*gridMode.rows).coerceAtLeast(1)
        val synthetic=LauncherApp("launcher-settings","Settings",isLauncherSettings=true)
        val available=(listOf(synthetic)+installedApps)
        val byId=available.associateBy { it.id }
        val saved=prefs?.getString("home_order", "").orEmpty().split("|").filter { it.isNotBlank() }
        val consumed=mutableSetOf<String>()
        val ordered=mutableListOf<LauncherApp>()
        saved.forEach { token ->
            if(token.startsWith("F|")) {
                val parts=token.split("|")
                if(parts.size>=4){
                    val folderId=decode(parts[1]); val name=decode(parts[2])
                    val children=decode(parts[3]).split(",").filter{it.isNotBlank()}.mapNotNull{byId[it]}
                    if(children.isNotEmpty()){
                        consumed.addAll(children.map{it.id})
                        ordered.add(LauncherApp(folderId,name,isFolder=true,folderItems=children))
                    }
                }
            } else {
                val id=decode(token).ifBlank { token }
                byId[id]?.let { if(!consumed.contains(it.id)) ordered.add(it) }
            }
        }
        available.forEach { item -> if(!consumed.contains(item.id) && ordered.none{it.id==item.id}) ordered.add(item) }
        // The expression above intentionally keeps every new item exactly once.
        val unique=ordered.distinctBy{it.id}.take(pageCapacity*3)
        pages=unique.chunked(pageCapacity).ifEmpty { listOf(emptyList()) }
    }

    private fun saveOrder(){
        val order=pages.flatten().joinToString("|") { item ->
            if(item.isFolder) "F|${encode(item.id)}|${encode(item.label)}|${encode(item.folderItems.joinToString(","){it.id})}"
            else encode(item.id)
        }
        prefs?.edit()?.putString("home_order", order)?.apply()
    }

    fun openFolder(id:String){ if(pages.flatten().any{it.id==id && it.isFolder}) openFolderId=id }
    fun closeFolder(){openFolderId=null}
    fun startFolderRename(id:String){folderRenameId=id}
    fun cancelFolderRename(){folderRenameId=null}
    fun renameFolder(id:String,name:String){
        val clean=name.trim().ifBlank{"Folder"}.take(28)
        pages=pages.map{page->page.map{if(it.id==id && it.isFolder) it.copy(label=clean) else it}}
        saveOrder(); folderRenameId=null
    }
    fun removeFromFolder(folderId:String,childId:String){
        val child=pages.flatten().firstOrNull{it.id==folderId && it.isFolder}?.folderItems?.firstOrNull{it.id==childId} ?: return
        pages=pages.map{page->page.map{item->
            if(item.id==folderId && item.isFolder){
                val remaining=item.folderItems.filterNot{it.id==childId}
                when(remaining.size){
                    0 -> null
                    1 -> remaining.first()
                    else -> item.copy(folderItems=remaining)
                }
            } else item
        }.filterNotNull()}
        saveOrder()
        if(pages.flatten().none{it.id==folderId}) openFolderId=null
    }
    fun moveInsideFolder(folderId:String,from:Int,to:Int){
        if(from==to)return
        pages=pages.map{page->page.map{item->
            if(item.id==folderId && item.isFolder){
                val list=item.folderItems.toMutableList(); if(from in list.indices && to in list.indices){val x=list.removeAt(from);list.add(to,x);item.copy(folderItems=list)} else item
            } else item
        }}
        saveOrder()
    }
    fun createFolder(page:Int,sourceIndex:Int,targetIndex:Int){
        if(page !in pages.indices || sourceIndex !in pages[page].indices || targetIndex !in pages[page].indices || sourceIndex==targetIndex)return
        val source=pages[page][sourceIndex]; val target=pages[page][targetIndex]
        if(source.isFolder || target.isFolder || source.isLauncherSettings || target.isLauncherSettings)return
        val id="folder:${java.util.UUID.randomUUID()}"
        val first=minOf(sourceIndex,targetIndex)
        val copy=pages[page].toMutableList()
        val a=copy.removeAt(maxOf(sourceIndex,targetIndex)); val b=copy.removeAt(first)
        val folder=LauncherApp(id,"Folder",isFolder=true,folderItems=listOf(b,a))
        copy.add(first,folder)
        val all=pages.toMutableList(); all[page]=copy; pages=all
        saveOrder(); openFolderId=id
    }
    fun addToFolder(page:Int,sourceIndex:Int,targetIndex:Int){
        if(page !in pages.indices || sourceIndex !in pages[page].indices || targetIndex !in pages[page].indices)return
        val source=pages[page][sourceIndex]; val target=pages[page][targetIndex]
        if(!target.isFolder || source.isFolder || source.isLauncherSettings)return
        val folder=target.copy(folderItems=(target.folderItems+source).distinctBy{it.id})
        val copy=pages[page].toMutableList(); copy.removeAt(sourceIndex)
        val newTargetIndex=copy.indexOfFirst{it.id==target.id}; if(newTargetIndex<0)return
        copy[newTargetIndex]=folder
        val all=pages.toMutableList();all[page]=copy;pages=all;saveOrder();openFolderId=folder.id
    }
    fun setCurrentHomePage(page:Int){ currentHomePage=page.coerceAtLeast(0); save{putInt("current_page",currentHomePage)} }
    fun openSettings(page:String="main"){settingsPage=page;settingsOpen=true}
    fun closeSettings(){settingsOpen=false;settingsPage="main"}
    fun setSettingsPage(page:String){settingsPage=page}
    fun openDrawer(){appDrawerOpen=true;appSearch="";drawerCategory="All"}
    fun closeDrawer(){appDrawerOpen=false;appSearch=""}
    fun setSearch(value:String){appSearch=value}
    fun setDrawerListMode(v:Boolean){drawerListMode=v}
    fun setDrawerCategory(v:String){drawerCategory=v}
    fun markRecent(app:LauncherApp){
        val id=app.id
        recentAppIds=(listOf(id)+recentAppIds.filterNot{it==id}).take(12)
        save{putString("recent_apps",recentAppIds.joinToString("|"))}
    }
    fun setGrid(mode:GridMode){gridMode=mode;save{putInt("grid",mode.ordinal)};rebuildPages()}
    fun setIconSize(v:IconSize){iconSize=v;save{putInt("iconSize",v.ordinal)}}
    fun setIconShape(v:IconShape){iconShape=v;save{putInt("iconShape",v.ordinal)}}
    fun toggleTheme(){setTheme(!darkMode)}
    fun setTheme(v:Boolean){darkMode=v;save{putBoolean("dark",v)}}
    fun setAnimationValue(v:Float){animationValue=v;save{putFloat("animValue",v)}}
    fun setAnimationDuration(v:Float){animationDuration=v;save{putFloat("animDuration",v)}}
    fun setAnimationType(v:AnimationType){animationType=v;save{putInt("animType",v.ordinal)}}
    fun setPerformanceMode(v:PerformanceMode){performanceMode=v;CURRENT_PERFORMANCE_MODE=v;ICON_CACHE.clear();save{putInt("performanceMode",v.ordinal)}}
    fun setWidgets(v:Boolean){widgetsEnabled=v;save{putBoolean("widgets",v)}}
    fun setGestures(v:Boolean){gesturesEnabled=v;save{putBoolean("gestures",v)}}
    fun setFolders(v:Boolean){foldersEnabled=v;save{putBoolean("folders",v)}}
    fun setSuggestions(v:Boolean){appSuggestionsEnabled=v;save{putBoolean("suggestions",v)}}
    fun setEdge(v:Boolean){edgePanelEnabled=v;save{putBoolean("edge",v)}}
    fun setBlur(v:Boolean){blurEnabled=v;save{putBoolean("blur",v)}}
    fun setWallpaper(uri:String?){wallpaperUri=uri;save{if(uri==null)remove("wallpaperUri") else putString("wallpaperUri",uri)}}
    fun setProductiveMode(v:Boolean){productiveMode=v;save{putBoolean("productiveMode",v)}}
    fun setStudyMode(v:Boolean){studyMode=v;save{putBoolean("studyMode",v)}}
    fun toggleStudyApp(id:String){studySelectedIds=if(studySelectedIds.contains(id))studySelectedIds-id else studySelectedIds+id;save{putString("studySelectedIds",studySelectedIds.joinToString("|"))}}
    fun studySelected(app:LauncherApp)=studySelectedIds.contains(app.id)
    fun visibleHomeApps(apps:List<LauncherApp>):List<LauncherApp>{
        if(studyMode) return apps.filter{it.isLauncherSettings || studySelectedIds.contains(it.id)}
        if(productiveMode) return apps.filter{it.isLauncherSettings || it.label.lowercase(Locale.getDefault()).contains(Regex("calendar|clock|notes|keep|files|drive|calculator|tasks|todo|docs|sheets"))}.take(gridMode.columns*gridMode.rows)
        return apps
    }
    fun cycleGrid()=setGrid(when(gridMode){GridMode.THREE_BY_FOUR->GridMode.FIVE_BY_FOUR;GridMode.FIVE_BY_FOUR->GridMode.FIVE_BY_SIX;GridMode.FIVE_BY_SIX->GridMode.THREE_BY_FOUR})
    fun moveApp(page:Int,from:Int,to:Int){
        if(page !in pages.indices)return
        val src=pages[page]
        if(from !in src.indices||to !in 0..src.lastIndex||from==to)return
        val copy=pages.map{it.toMutableList()}.toMutableList()
        val item=copy[page].removeAt(from)
        copy[page].add(to,item)
        pages=copy.map{it.toList()}
        saveOrder()
    }

    fun moveAcrossPages(sourcePage:Int,from:Int,targetPage:Int,targetIndex:Int){
        if(sourcePage !in pages.indices||targetPage !in pages.indices)return
        val capacity=gridMode.columns*gridMode.rows
        if(from !in pages[sourcePage].indices)return
        val flat=pages.flatten().toMutableList()
        val sourceGlobal=pages.take(sourcePage).sumOf { it.size }+from
        if(sourceGlobal !in flat.indices)return
        val item=flat.removeAt(sourceGlobal)
        val targetBefore=pages.take(targetPage).sumOf { it.size }
        val sourceWasBeforeTarget=sourcePage<targetPage
        val adjustedTarget=targetBefore-targetBefore.coerceAtLeast(0).let { if(sourceWasBeforeTarget) 1 else 0 }+targetIndex.coerceIn(0, capacity-1)
        val insertAt=adjustedTarget.coerceIn(0, flat.size)
        flat.add(insertAt,item)
        pages=flat.chunked(capacity).ifEmpty { listOf(emptyList()) }.take(3)
        saveOrder()
    }
    private fun decodeWidgets(raw:String):List<HomeWidgetRecord> = raw.split(";").mapNotNull { token ->
        val p=token.split(","); if(p.size>=4) runCatching { HomeWidgetRecord(p[0].toInt(),p[1].toInt(),p[2].toInt().coerceIn(1,5),p[3].toInt().coerceIn(1,6)) }.getOrNull() else null
    }
    private fun encodeWidgets(list:List<HomeWidgetRecord>) = list.joinToString(";") { "${it.appWidgetId},${it.page},${it.spanX},${it.spanY}" }
    fun addHomeWidget(id:Int, page:Int=0, spanX:Int=2, spanY:Int=2){
        homeWidgets=(homeWidgets.filterNot{it.appWidgetId==id}+HomeWidgetRecord(id,page,spanX,spanY)); save{putString("widgets_home",encodeWidgets(homeWidgets))}
    }
    fun removeHomeWidget(id:Int){homeWidgets=homeWidgets.filterNot{it.appWidgetId==id};save{putString("widgets_home",encodeWidgets(homeWidgets))}}
    fun moveHomeWidget(id:Int,page:Int){homeWidgets=homeWidgets.map{if(it.appWidgetId==id)it.copy(page=page.coerceAtLeast(0))else it};save{putString("widgets_home",encodeWidgets(homeWidgets))}}
    fun resizeHomeWidget(id:Int,dx:Int=0,dy:Int=0){homeWidgets=homeWidgets.map{if(it.appWidgetId==id)it.copy(spanX=(it.spanX+dx).coerceIn(1,5),spanY=(it.spanY+dy).coerceIn(1,6))else it};save{putString("widgets_home",encodeWidgets(homeWidgets))}}
    fun resetDefaults(context:Context){
        prefs?.edit()?.clear()?.apply(); gridMode=GridMode.FIVE_BY_FOUR; darkMode=false; iconSize=IconSize.MEDIUM; iconShape=IconShape.ROUNDED; animationValue=70f; animationDuration=500f; animationType=AnimationType.SPRING; performanceMode=PerformanceMode.HIGH; wallpaperUri=null; productiveMode=false; studyMode=false; studySelectedIds=emptySet(); widgetsEnabled=true; gesturesEnabled=true; foldersEnabled=true; appSuggestionsEnabled=false; edgePanelEnabled=false; blurEnabled=true; recentAppIds=emptyList(); homeWidgets=emptyList(); currentHomePage=0; settingsOpen=false; settingsPage="main"; appDrawerOpen=false; appSearch=""; rebuildPages()
    }
    fun requestDefaultHome(context:Context){
        if(Build.VERSION.SDK_INT>=29){
            val rm=context.getSystemService(RoleManager::class.java)
            if(rm?.isRoleAvailable(RoleManager.ROLE_HOME)==true && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                context.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
            }
        } else {
            runCatching { context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        }
    }
    fun launchApp(context:Context,app:LauncherApp){
        if(app.isLauncherSettings){openSettings();return}
        val pkg=app.packageName?:return;val activity=app.activityName?:return
        markRecent(app)
        try{context.startActivity(Intent().setComponent(ComponentName(pkg,activity)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}catch(_:Exception){}
    }
    val filteredApps:List<LauncherApp> get(){val q=appSearch.trim();return if(q.isEmpty()) installedApps else installedApps.filter{it.label.contains(q,true)}}
    private fun save(block:android.content.SharedPreferences.Editor.()->Unit){prefs?.edit()?.apply(block)?.apply()}
}

class MainActivity:ComponentActivity(){
    private lateinit var widgetHost:AppWidgetHost
    private lateinit var widgetManager:AppWidgetManager
    private lateinit var vm:LauncherViewModel
    private var pendingWidgetId:Int?=null
    private var pendingBindId:Int?=null
    companion object { const val HOST_ID=42042; const val REQ_PICK=9101; const val REQ_CONFIGURE=9102; const val REQ_BIND=9103; const val REQ_WALLPAPER=9104 }
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        vm=LauncherViewModel(); vm.init(this); widgetManager=AppWidgetManager.getInstance(this); widgetHost=AppWidgetHost(this,HOST_ID)
        setContent{ModernLauncherApp(vm,widgetHost,widgetManager)}
    }
    override fun onStart(){super.onStart();runCatching{widgetHost.startListening()}}
    override fun onResume(){super.onResume();runCatching{vm.refreshApps(this)}}
    override fun onNewIntent(intent:Intent?){ super.onNewIntent(intent); setIntent(intent) }
    override fun onStop(){runCatching{widgetHost.stopListening()};super.onStop()}
    fun pickWallpaper(){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"}
        startActivityForResult(intent,REQ_WALLPAPER)
    }
    fun pickWidget(){
        val id=widgetHost.allocateAppWidgetId(); pendingWidgetId=id
        startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id),REQ_PICK)
    }
    private fun bindOrConfigure(id:Int,info:AppWidgetProviderInfo){
        if(info.configure!=null){startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).setComponent(info.configure),REQ_CONFIGURE);return}
        if(widgetManager.bindAppWidgetIdIfAllowed(id,info.provider)){vm.addHomeWidget(id);return}
        pendingBindId=id
        startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,info.provider),REQ_BIND)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        when(requestCode){
            REQ_PICK->{val id=pendingWidgetId?:return; if(resultCode==RESULT_OK){val info=widgetManager.getAppWidgetInfo(id);if(info!=null)bindOrConfigure(id,info)}else widgetHost.deleteAppWidgetId(id);pendingWidgetId=null}
            REQ_CONFIGURE->{val id=pendingWidgetId?:return;if(resultCode==RESULT_OK)vm.addHomeWidget(id)else widgetHost.deleteAppWidgetId(id);pendingWidgetId=null}
            REQ_BIND->{val id=pendingBindId?:return;if(resultCode==RESULT_OK){vm.addHomeWidget(id)}else widgetHost.deleteAppWidgetId(id);pendingBindId=null}
            REQ_WALLPAPER->{if(resultCode==RESULT_OK){data?.data?.let{uri->runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};vm.setWallpaper(uri.toString())}}}
        }
    }
    fun resizeWidgetOptions(id:Int,spanX:Int,spanY:Int){
        val density=resources.displayMetrics.density
        val cellDp=72
        val options=widgetManager.getAppWidgetOptions(id)
        options.putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,(spanX*cellDp).coerceAtLeast(72))
        options.putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,(spanY*cellDp).coerceAtLeast(72))
        options.putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,(spanX*cellDp).coerceAtLeast(72))
        options.putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,(spanY*cellDp).coerceAtLeast(72))
        runCatching{widgetManager.updateAppWidgetOptions(id,options)}
    }
    fun deleteWidget(id:Int){vm.removeHomeWidget(id);runCatching{widgetHost.deleteAppWidgetId(id)}}
    fun hostView(id:Int):AppWidgetHostView? = runCatching{val info=widgetManager.getAppWidgetInfo(id) ?: return@runCatching null; widgetHost.createView(this,id,info)}.getOrNull()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun ModernLauncherApp(vm:LauncherViewModel, widgetHost:AppWidgetHost, widgetManager:AppWidgetManager){
    val context=LocalContext.current
    val activity=context as? MainActivity
    val pager=rememberPagerState(initialPage=vm.currentHomePage.coerceIn(0,vm.pages.lastIndex.coerceAtLeast(0)),pageCount={vm.pages.size.coerceAtLeast(1)})
    val scope=rememberCoroutineScope()
    LaunchedEffect(pager.currentPage){ vm.setCurrentHomePage(pager.currentPage) }
    val bg=if(vm.darkMode)Color(0xFF171717)else Color(0xFFF3F2EF);val surface=if(vm.darkMode)Color(0xFF222222)else Color(0xFFF7F6F2);val surface2=if(vm.darkMode)Color(0xFF292929)else Color(0xFFECEAE5);val text=if(vm.darkMode)Color(0xFFE8E6E2)else Color(0xFF4A4E52);val muted=text.copy(alpha=.52f);val accent=if(vm.darkMode)Color(0xFFFF9A9C)else Color(0xFFEE8F91)
    val wallpaper=produceState<ImageBitmap?>(null,vm.wallpaperUri){
        value=vm.wallpaperUri?.let{uri->runCatching{context.contentResolver.openInputStream(Uri.parse(uri))?.use{stream->android.graphics.BitmapFactory.decodeStream(stream)?.asImageBitmap()}}.getOrNull()}
    }.value
    MaterialTheme(colorScheme=if(vm.darkMode)darkColorScheme(background=bg,surface=surface,onBackground=text,onSurface=text,primary=accent)else lightColorScheme(background=bg,surface=surface,onBackground=text,onSurface=text,primary=accent)){
        Box(Modifier.fillMaxSize().background(bg).pointerInput(vm.settingsOpen,vm.gesturesEnabled){if(vm.gesturesEnabled)detectTapGestures(onLongPress={vm.openSettings()})}){
            if(wallpaper!=null) Image(wallpaper,contentDescription=null,modifier=Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.Crop,alpha=if(vm.darkMode).34f else .48f)
            Box(Modifier.fillMaxSize().background(bg.copy(alpha=if(wallpaper!=null).52f else .94f)))
            HorizontalPager(state=pager,modifier=Modifier.fillMaxSize(),beyondViewportPageCount=if(vm.performanceMode==PerformanceMode.HIGH) 1 else 0){page->
                val pageApps=vm.pages.getOrElse(page){emptyList()}
                HomePage(
                    pageIndex=page, apps=vm.visibleHomeApps(pageApps), vm=vm,
                    surface=surface, surface2=surface2, text=text, muted=muted, accent=accent,
                    onMove={from,to->if(!vm.studyMode && !vm.productiveMode)vm.moveApp(page,from,to)},
                    onCrossPage={from,direction,targetIndex->if(!vm.studyMode && !vm.productiveMode){
                        val targetPage=(page+direction).coerceIn(0,vm.pages.lastIndex)
                        if(targetPage!=page){
                            vm.moveAcrossPages(page,from,targetPage,targetIndex)
                            scope.launch { pager.animateScrollToPage(targetPage) }
                        }
                    }},
                    onCreateFolder={from,to->if(!vm.studyMode && !vm.productiveMode && vm.foldersEnabled) vm.createFolder(page,from,to)},
                    onAddToFolder={from,to->if(!vm.studyMode && !vm.productiveMode && vm.foldersEnabled) vm.addToFolder(page,from,to)},
                    onAddWidget={activity?.let { { it.pickWidget() } } ?: {}},
                    onMoveWidget={id,targetPage->vm.moveHomeWidget(id,targetPage)},
                    onResizeWidget={id,dx,dy->vm.resizeHomeWidget(id,dx,dy);vm.homeWidgets.firstOrNull{it.appWidgetId==id}?.let{activity?.resizeWidgetOptions(id,it.spanX,it.spanY)}},
                    onDeleteWidget={id->activity?.deleteWidget(id)}
                )
            }
            Row(Modifier.align(Alignment.TopEnd).padding(top=34.dp,end=16.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){TinyButton(if(vm.darkMode)"☀" else "☾"){vm.toggleTheme()};TinyButton(vm.gridMode.title){vm.cycleGrid()}}
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom=12.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){repeat(vm.pages.size.coerceAtLeast(1)){i->Box(Modifier.size(if(pager.currentPage==i)8.dp else 6.dp).background(if(pager.currentPage==i)accent else muted.copy(alpha=.35f),CircleShape))}}
            if(vm.settingsOpen)SettingsSheet(vm,bg,surface,text,muted,accent)
            if(vm.appDrawerOpen)AppDrawer(vm,bg,surface,text,muted,accent)
            vm.openFolderId?.let { folderId -> FolderOverlay(vm,folderId,bg,surface,text,muted,accent) }
            vm.folderRenameId?.let { folderId -> FolderRenameDialog(vm,folderId,text,accent) }
        }
    }
}

@Composable private fun TinyButton(label:String,onClick:()->Unit){Surface(onClick=onClick,shape=RoundedCornerShape(18.dp),tonalElevation=2.dp){Text(label,Modifier.padding(horizontal=10.dp,vertical=7.dp),fontSize=10.sp)}}

@Composable private fun SettingsSheet(vm:LauncherViewModel,bg:Color,surface:Color,text:Color,muted:Color,accent:Color){
    Box(Modifier.fillMaxSize().background(bg.copy(alpha=.94f)),contentAlignment=Alignment.Center){Surface(Modifier.fillMaxWidth(.90f).fillMaxHeight(.88f),shape=RoundedCornerShape(30.dp),color=surface,tonalElevation=6.dp){Column(Modifier.padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){if(vm.settingsPage!="main")Surface(onClick={vm.setSettingsPage("main")},shape=CircleShape,tonalElevation=2.dp){Text("‹",Modifier.padding(horizontal=12.dp,vertical=4.dp),fontSize=24.sp)};if(vm.settingsPage!="main")Spacer(Modifier.width(10.dp));Text(when(vm.settingsPage){"home"->"Home Screen";"dark"->"Dark Mode";"special"->"Special Features";"animation"->"Animation Control";"performance"->"Performance Mode";"wallpaper"->"Wallpaper";else->"Settings"},color=text,fontSize=22.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));Surface(onClick=vm::closeSettings,shape=CircleShape,tonalElevation=2.dp){Text("×",Modifier.padding(horizontal=10.dp,vertical=4.dp),fontSize=22.sp)}};Spacer(Modifier.height(18.dp));when(vm.settingsPage){"home"->HomeSettings(vm,text,muted,accent);"dark"->DarkSettings(vm,text,muted,accent);"special"->SpecialSettings(vm,text,muted,accent);"animation"->AnimationSettings(vm,text,muted,accent);"performance"->PerformanceSettings(vm,text,muted,accent);"wallpaper"->WallpaperSettings(vm,text,muted,accent);else->MainSettings(vm,text,muted,accent)}}}}
}

@Composable private fun MainSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){
    val context=LocalContext.current
    Column(verticalArrangement=Arrangement.spacedBy(12.dp),modifier=Modifier.verticalScroll(rememberScrollState())){
        SettingCard("⌂","Home Screen","Icon size · Shape · Grid size",text,muted){vm.setSettingsPage("home")}
        SettingCard("☾","Dark Mode",if(vm.darkMode)"Dark mode enabled" else "Light mode",text,muted){vm.setSettingsPage("dark")}
        SettingCard("✦","Special Features","Widgets · Gesture · Other",text,muted){vm.setSettingsPage("special")}
        SettingCard("✣","Animation Control","Animation value · Duration",text,muted){vm.setSettingsPage("animation")}
        SettingCard("⚡","Performance Mode",vm.performanceMode.title,text,muted){vm.setSettingsPage("performance")}
        SettingCard("▧","Wallpaper",if(vm.wallpaperUri==null)"Use your own wallpaper" else "Custom wallpaper selected",text,muted){vm.setSettingsPage("wallpaper")}
        Surface(onClick={vm::toggleTheme},shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth()){Text(if(vm.darkMode)"Switch to Light Mode" else "Switch to Dark Mode",color=text,fontSize=12.sp,modifier=Modifier.padding(15.dp))}
        Surface(onClick={vm::resetDefaults},shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth()){Text("Reset launcher settings",color=accent,fontSize=12.sp,modifier=Modifier.padding(15.dp))}
        Surface(onClick={ vm.requestDefaultHome(context) },shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth()){Text("Set as default Home app",color=text,fontSize=12.sp,modifier=Modifier.padding(15.dp))}
    }
}

@Composable private fun SettingCard(icon:String,title:String,subtitle:String,text:Color,muted:Color,onClick:()->Unit){Surface(onClick=onClick,shape=RoundedCornerShape(22.dp),tonalElevation=2.dp,modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).shadow(4.dp,CircleShape).background(MaterialTheme.colorScheme.surface,CircleShape),contentAlignment=Alignment.Center){Text(icon,color=MaterialTheme.colorScheme.primary,fontSize=20.sp)};Spacer(Modifier.width(13.dp));Column(Modifier.weight(1f)){Text(title,color=text,fontSize=15.sp,fontWeight=FontWeight.Medium);Text(subtitle,color=muted,fontSize=10.sp)};Text("›",color=muted,fontSize=24.sp)}}}
@Composable private fun HomeSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(18.dp)){OptionGroup("Icon Size",text){ChoiceRow(IconSize.values().toList(),vm.iconSize,{it.title},accent,vm::setIconSize)};OptionGroup("Shape",text){ChoiceRow(IconShape.values().toList(),vm.iconShape,{it.title},accent,vm::setIconShape)};OptionGroup("Grid Size",text){ChoiceRow(GridMode.values().toList(),vm.gridMode,{it.title},accent,vm::setGrid)}}}
@Composable private fun OptionGroup(title:String,text:Color,content:@Composable () -> Unit){Column{Text(title,color=text,fontSize=13.sp,fontWeight=FontWeight.Medium);Spacer(Modifier.height(8.dp));content()}}
@Composable private fun <T> ChoiceRow(items:List<T>,selected:T,label:(T)->String,accent:Color,onSelect:(T)->Unit){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){items.forEach{item->val active=item==selected;Surface(onClick={onSelect(item)},shape=RoundedCornerShape(16.dp),tonalElevation=if(active)4.dp else 1.dp,modifier=Modifier.weight(1f).height(58.dp).border(if(active)1.dp else 0.dp,if(active)accent else Color.Transparent,RoundedCornerShape(16.dp))){Box(contentAlignment=Alignment.Center,modifier=Modifier.fillMaxSize()){Text(label(item),fontSize=10.sp,color=if(active)accent else MaterialTheme.colorScheme.onSurface)}}}}}
@Composable private fun DarkSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){Column(verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Choose the launcher theme",color=muted,fontSize=12.sp);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){ThemeChoice("☀","Light Mode",!vm.darkMode,text,accent){vm.setTheme(false)};ThemeChoice("☾","Dark Mode",vm.darkMode,text,accent){vm.setTheme(true)}};Surface(onClick=vm::toggleTheme,shape=RoundedCornerShape(20.dp),tonalElevation=2.dp,modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Quick theme toggle",color=text,fontSize=13.sp);Text("Use the top-right control",color=muted,fontSize=10.sp)};Switch(vm.darkMode,{vm.toggleTheme()})}}}}
@Composable private fun ThemeChoice(icon:String,title:String,active:Boolean,text:Color,accent:Color,onClick:()->Unit){Surface(onClick=onClick,shape=RoundedCornerShape(20.dp),tonalElevation=if(active)5.dp else 1.dp,modifier=Modifier.weight(1f).height(145.dp).border(if(active)2.dp else 0.dp,if(active)accent else Color.Transparent,RoundedCornerShape(20.dp))){Column(Modifier.fillMaxSize().padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(icon,fontSize=28.sp,color=if(active)accent else text);Spacer(Modifier.height(10.dp));Text(title,color=text,fontSize=12.sp,fontWeight=if(active)FontWeight.SemiBold else FontWeight.Normal)}}}
@Composable private fun WallpaperSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){
    val context=LocalContext.current
    Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Personalize the launcher background",color=muted,fontSize=12.sp)
        Surface(onClick={(context as? MainActivity)?.pickWallpaper()},shape=RoundedCornerShape(22.dp),tonalElevation=2.dp,modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(18.dp)){Text("Choose wallpaper",color=text,fontSize=14.sp,fontWeight=FontWeight.Medium);Text("Select an image from your device",color=muted,fontSize=10.sp)}
        }
        if(vm.wallpaperUri!=null) Surface(onClick={vm.setWallpaper(null)},shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth()){Text("Remove custom wallpaper",color=accent,fontSize=12.sp,modifier=Modifier.padding(15.dp))}
    }
}

@Composable private fun SpecialSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){
    val context=LocalContext.current
    Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
        FeatureToggle("▦","Widgets","Show widgets on home screen",vm.widgetsEnabled,accent,vm::setWidgets)
        FeatureToggle("☝","Gesture","Swipe, double tap, long press",vm.gesturesEnabled,accent,vm::setGestures)
        FeatureToggle("□","Folder Support","Create and manage folders",vm.foldersEnabled,accent,vm::setFolders)
        FeatureToggle("✦","App Suggestions","Show smart app suggestions",vm.appSuggestionsEnabled,accent,vm::setSuggestions)
        FeatureToggle("▯","Edge Panel","Quick tools from edge",vm.edgePanelEnabled,accent,vm::setEdge)
        FeatureToggle("☼","Blur Effect","Background blur effect",vm.blurEnabled,accent,vm::setBlur)
        Spacer(Modifier.height(4.dp))
        FeatureToggle("◉","Productive Mode","Focused work-oriented home layout",vm.productiveMode,accent,vm::setProductiveMode)
        FeatureToggle("📚","Study Mode","Selective apps and dedicated study layout",vm.studyMode,accent,vm::setStudyMode)
        if(vm.studyMode){
            Text("Study apps",color=text,fontSize=13.sp,fontWeight=FontWeight.Medium,modifier=Modifier.padding(top=6.dp))
            Text("Select the apps allowed on the Study home screen.",color=muted,fontSize=10.sp)
            vm.installedApps.forEach{app->
                Surface(onClick={vm.toggleStudyApp(app.id)},shape=RoundedCornerShape(16.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth()){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){AppIcon(app,Modifier.size(34.dp),accent);Spacer(Modifier.width(10.dp));Text(app.label,color=text,fontSize=11.sp,modifier=Modifier.weight(1f));Text(if(vm.studySelected(app))"✓" else "○",color=if(vm.studySelected(app))accent else muted,fontSize=18.sp)}}
            }
        }
    }
}
@Composable private fun FeatureToggle(icon:String,title:String,subtitle:String,value:Boolean,accent:Color,onChange:(Boolean)->Unit){Surface(shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(38.dp).background(MaterialTheme.colorScheme.surfaceVariant,CircleShape),contentAlignment=Alignment.Center){Text(icon,color=accent)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontSize=12.sp,fontWeight=FontWeight.Medium);Text(subtitle,fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f))};Switch(value,onChange)}}}
@Composable private fun PerformanceSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Choose rendering performance mode",color=muted,fontSize=12.sp);PerformanceChoice(PerformanceMode.HIGH,vm.performanceMode==PerformanceMode.HIGH,text,accent,vm::setPerformanceMode);PerformanceChoice(PerformanceMode.LITE,vm.performanceMode==PerformanceMode.LITE,text,accent,vm::setPerformanceMode);Spacer(Modifier.height(4.dp));Text("Performance mode changes rendering/memory behavior only. Your animation slider, duration and animation type are not reduced automatically.",color=muted,fontSize=11.sp)}}

@Composable private fun PerformanceChoice(mode:PerformanceMode,selected:Boolean,text:Color,accent:Color,onSelect:(PerformanceMode)->Unit){Surface(onClick={onSelect(mode)},shape=RoundedCornerShape(20.dp),tonalElevation=if(selected)4.dp else 1.dp,modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(if(mode==PerformanceMode.HIGH)"⚡" else "◌",color=accent,fontSize=20.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(mode.title,color=text,fontSize=14.sp,fontWeight=FontWeight.Medium);Text(mode.subtitle,color=text.copy(alpha=.52f),fontSize=10.sp)};if(selected)Text("✓",color=accent,fontSize=20.sp)}}}

@Composable private fun AnimationSettings(vm:LauncherViewModel,text:Color,muted:Color,accent:Color){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(16.dp)){SliderCard("Animation Value","Control the smoothness of animations",vm.animationValue,"${vm.animationValue.roundToInt()}%",accent,0f,100f,vm::setAnimationValue);SliderCard("Animation Duration","Set the speed of animations",vm.animationDuration,"${vm.animationDuration.roundToInt()} ms",accent,100f,1000f,vm::setAnimationDuration);Text("Animation Type",color=text,fontSize=13.sp,fontWeight=FontWeight.Medium);ChoiceRow(AnimationType.values().toList(),vm.animationType,{it.title},accent,vm::setAnimationType)}}
@Composable private fun SliderCard(title:String,subtitle:String,value:Float,valueText:String,accent:Color,min:Float,max:Float,onChange:(Float)->Unit){Surface(shape=RoundedCornerShape(20.dp),tonalElevation=2.dp,modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Row{Column(Modifier.weight(1f)){Text(title,fontSize=13.sp,fontWeight=FontWeight.Medium);Text(subtitle,fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f))};Text(valueText,fontSize=10.sp,color=accent)};Slider(value,onChange,valueRange=min..max)}}}

@Composable private fun HomePage(pageIndex:Int,apps:List<LauncherApp>,vm:LauncherViewModel,surface:Color,surface2:Color,text:Color,muted:Color,accent:Color,onMove:(Int,Int)->Unit,onCrossPage:(Int,Int,Int)->Unit,onCreateFolder:(Int,Int)->Unit,onAddToFolder:(Int,Int)->Unit,onAddWidget:()->Unit,onMoveWidget:(Int,Int)->Unit,onResizeWidget:(Int,Int,Int)->Unit,onDeleteWidget:(Int)->Unit){
    val now=remember{mutableStateOf(Date())};LaunchedEffect(Unit){while(true){kotlinx.coroutines.delay(30_000);now.value=Date()}}
    val time=SimpleDateFormat("HH:mm",Locale.getDefault()).format(now.value);val hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);val greeting=when{hour<12->"Good Morning";hour<18->"Good Afternoon";else->"Good Evening"};val date=SimpleDateFormat("EEEE, MMMM d",Locale.getDefault()).format(now.value)
    val launchContext=LocalContext.current
    var swipeUp by remember { mutableFloatStateOf(0f) }
    val homeModifier=Modifier.fillMaxSize().padding(horizontal=24.dp,vertical=28.dp).let{base->
        if(vm.gesturesEnabled) base.pointerInput(Unit){detectVerticalDragGestures(
            onVerticalDrag={change,amount->if(amount<0)change.consume();swipeUp+=amount},
            onDragEnd={if(swipeUp < -90f)vm.openDrawer();swipeUp=0f},
            onDragCancel={swipeUp=0f}
        )} else base
    }
    Column(homeModifier){
        Spacer(Modifier.height(14.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){AnalogClock(text);Spacer(Modifier.width(18.dp));Column{Text(greeting,color=text,fontSize=18.sp,fontWeight=FontWeight.Medium);Text(date,color=muted,fontSize=12.sp)}}
        Spacer(Modifier.height(18.dp));Surface(Modifier.fillMaxWidth().height(70.dp),shape=RoundedCornerShape(24.dp),color=surface,tonalElevation=1.dp){Column(Modifier.padding(horizontal=20.dp,vertical=10.dp)){Text(time,color=text,fontSize=30.sp,fontWeight=FontWeight.Light);Text("Focus · ${vm.gridMode.title} grid",color=muted,fontSize=9.sp)}}
        Spacer(Modifier.height(11.dp));Box(Modifier.fillMaxWidth().height(26.dp).clip(RoundedCornerShape(13.dp)).background(surface)){Box(Modifier.fillMaxWidth(.58f).fillMaxHeight().background(accent,RoundedCornerShape(13.dp)));Text("58%",Modifier.align(Alignment.Center),color=text,fontSize=9.sp)}
        Spacer(Modifier.height(11.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){Metric("Steps","6.2k",surface,text,Modifier.weight(1f));Metric("Water","1.4L",surface,text,Modifier.weight(1f));Metric("Sleep","7h 20m",surface,text,Modifier.weight(1f))}
        Spacer(Modifier.height(11.dp));CalendarCard(surface,text,muted,accent)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){Surface(onClick={vm.openDrawer()},shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.weight(1f).height(46.dp)){Row(Modifier.padding(horizontal=15.dp),verticalAlignment=Alignment.CenterVertically){Text("⌕",color=accent,fontSize=19.sp);Spacer(Modifier.width(10.dp));Text("Search apps…",color=muted,fontSize=11.sp);Spacer(Modifier.weight(1f));Text("Swipe up",color=muted,fontSize=9.sp)}};if(vm.widgetsEnabled)Surface(onClick=onAddWidget,shape=RoundedCornerShape(18.dp),tonalElevation=2.dp,modifier=Modifier.size(46.dp)){Text("+",color=accent,fontSize=22.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}}
        if(vm.widgetsEnabled && vm.homeWidgets.any{it.page==pageIndex}){
            vm.homeWidgets.filter{it.page==pageIndex}.forEach { record ->
                HomeWidgetCard(record,widgetHost=(launchContext as? MainActivity)?.let { it },surface=surface,text=text,accent=accent,onMovePage={dir->onMoveWidget(record.appWidgetId,(pageIndex+dir).coerceIn(0,vm.pages.lastIndex))},onResize={dx,dy->onResizeWidget(record.appWidgetId,dx,dy)},onDelete={onDeleteWidget(record.appWidgetId)})
                Spacer(Modifier.height(8.dp))
            }
        }
        Spacer(Modifier.weight(1f));DragGrid(apps,vm.gridMode,surface,text,accent,vm.iconSize,vm.iconShape,vm.animationType,vm.animationDuration,{app->if(app.isFolder) vm.openFolder(app.id) else vm.launchApp(launchContext,app)},onMove,onCrossPage,onCreateFolder,onAddToFolder);Spacer(Modifier.height(8.dp));Surface(onClick=vm::openDrawer,shape=RoundedCornerShape(22.dp),tonalElevation=2.dp,modifier=Modifier.align(Alignment.CenterHorizontally).height(42.dp)){Row(Modifier.padding(horizontal=18.dp),verticalAlignment=Alignment.CenterVertically){Text("⌃",color=accent,fontSize=18.sp);Spacer(Modifier.width(8.dp));Text("All Apps",color=text,fontSize=11.sp)}};Spacer(Modifier.height(12.dp))
    }
}

@Composable private fun HomeWidgetCard(record:HomeWidgetRecord,widgetHost:MainActivity?,surface:Color,text:Color,accent:Color,onMovePage:(Int)->Unit,onResize:(Int,Int)->Unit,onDelete:()->Unit){
    var dragX by remember(record.appWidgetId){mutableFloatStateOf(0f)}
    Surface(shape=RoundedCornerShape(22.dp),color=surface,tonalElevation=3.dp,modifier=Modifier.fillMaxWidth().height((record.spanY*68).dp).pointerInput(record.appWidgetId){detectDragGesturesAfterLongPress(onDragStart={dragX=0f},onDrag={change,amount->change.consume();dragX+=amount.x},onDragEnd={when{dragX>180->onMovePage(1);dragX< -180->onMovePage(-1)};dragX=0f},onDragCancel={dragX=0f})}){
        Box(Modifier.fillMaxSize()){
            AndroidView(factory={ctx->widgetHost?.hostView(record.appWidgetId) ?: AppWidgetHostView(ctx)},modifier=Modifier.fillMaxSize().padding(8.dp),update={view->view.layoutParams=android.widget.FrameLayout.LayoutParams(-1,-1)})
            Row(Modifier.align(Alignment.TopEnd).padding(7.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                Surface(onClick={onResize(-1,0)},shape=CircleShape,tonalElevation=2.dp){Text("−",fontSize=13.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=4.dp))}
                Surface(onClick={onResize(1,0)},shape=CircleShape,tonalElevation=2.dp){Text("+",fontSize=13.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=4.dp))}
                Surface(onClick=onDelete,shape=CircleShape,tonalElevation=2.dp){Text("×",fontSize=13.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=4.dp),color=accent)}
            }
        }
    }
}

@Composable private fun AnalogClock(text:Color){Box(Modifier.size(116.dp).shadow(8.dp,CircleShape).background(Color.Transparent,CircleShape).border(1.dp,text.copy(alpha=.08f),CircleShape),contentAlignment=Alignment.Center){Text("10:10",color=text,fontSize=25.sp,fontWeight=FontWeight.Light)}}
@Composable private fun Metric(title:String,value:String,surface:Color,text:Color,modifier:Modifier){Surface(modifier.height(76.dp),shape=RoundedCornerShape(20.dp),color=surface,tonalElevation=1.dp){Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.Center){Text(title,color=text.copy(alpha=.48f),fontSize=10.sp);Text(value,color=text,fontSize=13.sp,fontWeight=FontWeight.Medium)}}}
@Composable private fun CalendarCard(surface:Color,text:Color,muted:Color,accent:Color){Surface(Modifier.fillMaxWidth().height(112.dp),shape=RoundedCornerShape(24.dp),color=surface,tonalElevation=1.dp){Column(Modifier.padding(14.dp)){Text(SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date()),color=text,fontSize=13.sp,fontWeight=FontWeight.Medium);Spacer(Modifier.height(7.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){listOf("M","T","W","T","F","S","S").forEach{Text(it,color=muted,fontSize=9.sp)}};Spacer(Modifier.height(7.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){(13..19).forEach{day->Box(Modifier.size(25.dp).background(if(day==13)accent else Color.Transparent,CircleShape),contentAlignment=Alignment.Center){Text(day.toString(),color=if(day==13)Color.White else text,fontSize=9.sp)}}}}}}

@Composable private fun DragGrid(
    apps:List<LauncherApp>, grid:GridMode, surface:Color, text:Color, accent:Color,
    iconSize:IconSize, iconShape:IconShape, animationType:AnimationType, animationDuration:Float,
    onLaunch:(LauncherApp)->Unit, onMove:(Int,Int)->Unit, onCrossPage:(Int,Int,Int)->Unit, onCreateFolder:(Int,Int)->Unit, onAddToFolder:(Int,Int)->Unit
){
    val visible=apps.take(grid.columns*grid.rows)
    var dragging by remember { mutableIntStateOf(-1) }
    var target by remember { mutableIntStateOf(-1) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var edgeHint by remember { mutableIntStateOf(0) }
    val density=androidx.compose.ui.platform.LocalDensity.current
    val iconDp=iconSize.dp.dp
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx=with(density){maxWidth.toPx()}
        val gapPx=with(density){7.dp.toPx()}
        val cellWidth=(widthPx-gapPx*(grid.columns-1))/grid.columns.coerceAtLeast(1)
        val cellHeight=with(density){70.dp.toPx()+8.dp.toPx()}
        Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            visible.chunked(grid.columns).forEachIndexed { row,rowApps ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    repeat(grid.columns) { col ->
                        val index=row*grid.columns+col
                        Box(Modifier.weight(1f).height(70.dp),contentAlignment=Alignment.Center){
                            val app=rowApps.getOrNull(col)
                            if(app!=null){
                                val isDragging=index==dragging
                                val displayIndex=when {
                                    dragging<0 || target<0 || index==dragging -> index
                                    dragging<target && index in (dragging+1)..target -> index-1
                                    dragging>target && index in target until dragging -> index+1
                                    else -> index
                                }
                                val fromCol=index%grid.columns
                                val fromRow=index/grid.columns
                                val toCol=displayIndex%grid.columns
                                val toRow=displayIndex/grid.columns
                                val dx=(toCol-fromCol)*cellWidth + if(isDragging) offset.x else 0f
                                val dy=(toRow-fromRow)*cellHeight + if(isDragging) offset.y else 0f
                                val scale=if(isDragging)1.12f else 1f
                                val elevation=if(isDragging)18.dp else 6.dp
                                val springSpec=androidx.compose.animation.core.spring<Float>(
                                    dampingRatio=0.82f, stiffness=300f
                                )
                                val animatedX by androidx.compose.animation.core.animateFloatAsState(dx,animationSpec=springSpec,label="dragX")
                                val animatedY by androidx.compose.animation.core.animateFloatAsState(dy,animationSpec=springSpec,label="dragY")
                                Box(
                                    Modifier
                                        .graphicsLayer{translationX=if(isDragging)dx else animatedX;translationY=if(isDragging)dy else animatedY;scaleX=scale;scaleY=scale;shadowElevation=with(density){(if(elevation.value > 10f) 10.dp else elevation).toPx()}}
                                        .pointerInput(app.id,visible.size,grid){
                                            detectDragGesturesAfterLongPress(
                                                onDragStart={dragging=index;target=index;offset=androidx.compose.ui.geometry.Offset.Zero;edgeHint=0},
                                                onDrag={change,amount->
                                                    change.consume();offset+=amount
                                                    val colShift=(offset.x/cellWidth).roundToInt()
                                                    val rowShift=(offset.y/cellHeight).roundToInt()
                                                    val sr=index/grid.columns;val sc=index%grid.columns
                                                    val nr=(sr+rowShift).coerceIn(0,grid.rows-1)
                                                    val nc=(sc+colShift).coerceIn(0,grid.columns-1)
                                                    target=(nr*grid.columns+nc).coerceIn(0,(visible.size-1).coerceAtLeast(0))
                                                    edgeHint=when { offset.x>widthPx*.42f -> 1; offset.x< -widthPx*.42f -> -1; else -> 0 }
                                                },
                                                onDragCancel={dragging=-1;target=-1;offset=androidx.compose.ui.geometry.Offset.Zero;edgeHint=0},
                                                onDragEnd={
                                                    val d=dragging;val t=target;val e=edgeHint
                                                    if(d>=0&&t>=0){
                                                        if(e!=0){
                                                            val targetIndex=(t.coerceIn(0,visible.size-1))
                                                            onCrossPage(d,e,targetIndex)
                                                        } else if(d!=t){
                                                            val targetItem=visible.getOrNull(t)
                                                            when {
                                                                targetItem?.isFolder == true -> onAddToFolder(d,t)
                                                                targetItem?.isLauncherSettings == false && targetItem != null -> onCreateFolder(d,t)
                                                                else -> onMove(d,t)
                                                            }
                                                        }
                                                    }
                                                    dragging=-1;target=-1;offset=androidx.compose.ui.geometry.Offset.Zero;edgeHint=0
                                                }
                                            )
                                        }
                                        .clickableWithoutRipple{if(app.isFolder) onLaunch(app) else onLaunch(app)},
                                    contentAlignment=Alignment.Center
                                ) { LauncherIcon(app,surface,text,accent,elevation,iconDp,iconShape) }
                            }
                        }
                    }
                }
            }
        }
        if(dragging>=0 && edgeHint!=0){
            Surface(
                shape=RoundedCornerShape(16.dp), color=surface, tonalElevation=5.dp,
                modifier=Modifier.align(if(edgeHint>0)Alignment.CenterEnd else Alignment.CenterStart).padding(horizontal=6.dp)
            ){ Text(if(edgeHint>0)"Release →" else "← Release",color=accent,fontSize=10.sp,fontWeight=FontWeight.Medium,modifier=Modifier.padding(horizontal=10.dp,vertical=7.dp)) }
        }
    }
}

@Composable private fun LauncherIcon(app:LauncherApp,surface:Color,text:Color,accent:Color,elevation:androidx.compose.ui.unit.Dp,size:androidx.compose.ui.unit.Dp,shapeType:IconShape){val shape=when(shapeType){IconShape.CIRCLE->CircleShape;IconShape.ROUNDED->RoundedCornerShape(16.dp);IconShape.SQUARE->RoundedCornerShape(5.dp)};Column(horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(size).shadow(elevation,shape).background(surface,shape),contentAlignment=Alignment.Center){AppIcon(app,Modifier.size((size.value*.52f).dp),accent)};Spacer(Modifier.height(3.dp));Text(app.label,color=text.copy(alpha=.64f),fontSize=8.sp,maxLines=1)}}

@Composable private fun AppIcon(app:LauncherApp,modifier:Modifier,accent:Color){
    val context=LocalContext.current
    if(app.isLauncherSettings){Text("⚙",modifier,color=accent,fontSize=22.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center);return}
    if(app.isFolder){
        Box(modifier,contentAlignment=Alignment.Center){
            val children=app.folderItems.take(4)
            Column(verticalArrangement=Arrangement.spacedBy(2.dp),horizontalAlignment=Alignment.CenterHorizontally){
                Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){children.take(2).forEach{AppIcon(it,Modifier.size(16.dp),accent)}}
                Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){children.drop(2).take(2).forEach{AppIcon(it,Modifier.size(16.dp),accent)}}
            }
        }
        return
    }
    val bitmap=remember(app.id){loadAppIcon(context,app)}
    if(bitmap!=null) androidx.compose.foundation.Image(bitmap=bitmap,contentDescription=app.label,modifier=modifier) else Text("•",modifier,color=accent,fontSize=24.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
}

private val ICON_CACHE = ConcurrentHashMap<String, ImageBitmap?>()
@Volatile private var CURRENT_PERFORMANCE_MODE:PerformanceMode=PerformanceMode.HIGH

private fun loadAppIcon(context:Context,app:LauncherApp):ImageBitmap? {
    val key = app.id
    ICON_CACHE[key]?.let { return it }
    return try {
        val d=context.packageManager.getActivityIcon(ComponentName(app.packageName!!,app.activityName!!))
        val bitmap=drawableToBitmap(d,if(CURRENT_PERFORMANCE_MODE==PerformanceMode.HIGH)96 else 64).asImageBitmap()
        ICON_CACHE[key]=bitmap
        bitmap
    } catch(_:Exception) {
        ICON_CACHE[key]=null
        null
    }
}

private fun drawableToBitmap(drawable:Drawable,maxSize:Int=64):Bitmap {
    if(drawable is BitmapDrawable && drawable.bitmap!=null){
        val b=drawable.bitmap
        if(b.width<=maxSize && b.height<=maxSize) return b
    }
    val iw=(drawable.intrinsicWidth.takeIf{it>0}?:64)
    val ih=(drawable.intrinsicHeight.takeIf{it>0}?:64)
    val scale=minOf(1f,maxSize.toFloat()/iw,maxSize.toFloat()/ih)
    val w=maxOf(1,(iw*scale).toInt()); val h=maxOf(1,(ih*scale).toInt())
    return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also{bitmap->
        val c=Canvas(bitmap); drawable.setBounds(0,0,w,h); drawable.draw(c)
    }
}


@Composable private fun FolderOverlay(vm:LauncherViewModel,folderId:String,bg:Color,surface:Color,text:Color,muted:Color,accent:Color){
    val folder=vm.pages.flatten().firstOrNull{it.id==folderId && it.isFolder}
    if(folder==null){ LaunchedEffect(folderId){ vm.closeFolder() }; return }
    var folderShown by remember(folderId){mutableStateOf(false)}
    LaunchedEffect(folderId){folderShown=true}
    val scale=androidx.compose.animation.core.animateFloatAsState(if(folderShown)1f else .88f, androidx.compose.animation.core.spring(dampingRatio=.82f,stiffness=300f), label="folderScale").value
    val context=LocalContext.current
    fun closeAnimated(){ folderShown=false }
    BackHandlerCompat{closeAnimated()}
    LaunchedEffect(folderShown){ if(!folderShown) { kotlinx.coroutines.delay(120); vm.closeFolder() } }
    Box(Modifier.fillMaxSize().background(bg.copy(alpha=.72f)),contentAlignment=Alignment.Center){
        Surface(onClick={closeAnimated()},modifier=Modifier.fillMaxSize(),color=Color.Transparent){ }
        Surface(Modifier.fillMaxWidth(.86f).wrapContentHeight().graphicsLayer{scaleX=scale;scaleY=scale},shape=RoundedCornerShape(30.dp),color=surface,tonalElevation=12.dp){
            Column(Modifier.padding(20.dp)){
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.weight(1f)){Text(folder.label,color=text,fontSize=21.sp,fontWeight=FontWeight.SemiBold);Text("${folder.folderItems.size} apps",color=muted,fontSize=10.sp)}
                    Surface(onClick={vm.startFolderRename(folder.id)},shape=CircleShape,tonalElevation=2.dp){Text("✎",color=accent,modifier=Modifier.padding(10.dp))}
                    Spacer(Modifier.width(7.dp));Surface(onClick={closeAnimated()},shape=CircleShape,tonalElevation=2.dp){Text("×",modifier=Modifier.padding(horizontal=10.dp,vertical=5.dp),fontSize=20.sp)}
                }
                Spacer(Modifier.height(14.dp))
                var folderDragging by remember(folder.id){mutableIntStateOf(-1)}
                var folderTarget by remember(folder.id){mutableIntStateOf(-1)}
                var folderOffset by remember(folder.id){mutableStateOf(androidx.compose.ui.geometry.Offset.Zero)}
                val density=androidx.compose.ui.platform.LocalDensity.current
                BoxWithConstraints(Modifier.fillMaxWidth().heightIn(min=150.dp,max=360.dp)){
                    val cols=vm.gridMode.columns.coerceAtMost(5)
                    val gap=with(density){8.dp.toPx()}
                    val cell=((maxWidth.toPx()-gap*(cols-1))/cols).coerceAtLeast(1f)
                    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(columns=GridCells.Fixed(cols),contentPadding=PaddingValues(4.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxSize()){
                        items(folder.folderItems,key={it.id}){app->
                            val index=folder.folderItems.indexOfFirst{it.id==app.id}
                            val isDragging=index==folderDragging
                            val displayIndex=when{
                                folderDragging<0||folderTarget<0||index==folderDragging->index
                                folderDragging<folderTarget && index in (folderDragging+1)..folderTarget->index-1
                                folderDragging>folderTarget && index in folderTarget until folderDragging->index+1
                                else->index
                            }
                            val dx=(displayIndex%cols-index%cols)*cell + if(isDragging) folderOffset.x else 0f
                            val dy=(displayIndex/cols-index/cols)*(86.dp.value*density+gap) + if(isDragging) folderOffset.y else 0f
                            val ax by androidx.compose.animation.core.animateFloatAsState(dx,androidx.compose.animation.core.spring(dampingRatio=.82f,stiffness=300f),label="folderX")
                            val ay by androidx.compose.animation.core.animateFloatAsState(dy,androidx.compose.animation.core.spring(dampingRatio=.82f,stiffness=300f),label="folderY")
                            Surface(onClick={if(!isDragging){vm.launchApp(context,app);closeAnimated()}},shape=RoundedCornerShape(18.dp),tonalElevation=if(isDragging)8.dp else 2.dp,modifier=Modifier.height(86.dp).graphicsLayer{translationX=if(isDragging)dx else ax;translationY=if(isDragging)dy else ay;scaleX=if(isDragging)1.08f else 1f;scaleY=if(isDragging)1.08f else 1f}.pointerInput(app.id,folder.folderItems.size){
                                detectDragGesturesAfterLongPress(
                                    onDragStart={folderDragging=index;folderTarget=index;folderOffset=androidx.compose.ui.geometry.Offset.Zero},
                                    onDrag={change,amount->change.consume();folderOffset+=amount;val cs=(folderOffset.x/cell).roundToInt();val rs=(folderOffset.y/(86.dp.value*density+gap)).roundToInt();val tc=(index%cols+cs).coerceIn(0,cols-1);val tr=(index/cols+rs).coerceAtLeast(0);folderTarget=(tr*cols+tc).coerceIn(0,folder.folderItems.lastIndex)},
                                    onDragCancel={folderDragging=-1;folderTarget=-1;folderOffset=androidx.compose.ui.geometry.Offset.Zero},
                                    onDragEnd={val from=folderDragging;val to=folderTarget;if(from>=0&&to>=0&&from!=to)vm.moveInsideFolder(folder.id,from,to);folderDragging=-1;folderTarget=-1;folderOffset=androidx.compose.ui.geometry.Offset.Zero}
                                )
                            }){
                                Column(Modifier.fillMaxSize().padding(7.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){AppIcon(app,Modifier.size(42.dp),accent);Text(app.label,color=text,fontSize=8.sp,maxLines=1,textAlign=TextAlign.Center)}
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Long-press an app to rearrange • Tap ✎ to rename",color=muted,fontSize=9.sp)
                if(folder.folderItems.isNotEmpty()){
                    Spacer(Modifier.height(8.dp));Text("Remove apps",color=text,fontSize=12.sp,fontWeight=FontWeight.Medium)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        folder.folderItems.forEach { app -> Surface(onClick={vm.removeFromFolder(folder.id,app.id)},shape=RoundedCornerShape(14.dp),tonalElevation=1.dp){Text("× ${app.label}",color=muted,fontSize=8.sp,modifier=Modifier.padding(horizontal=8.dp,vertical=6.dp))} }
                    }
                }
            }
        }
    }
}

@Composable private fun FolderRenameDialog(vm:LauncherViewModel,folderId:String,text:Color,accent:Color){
    val folder=vm.pages.flatten().firstOrNull{it.id==folderId && it.isFolder} ?: return
    var name by remember(folderId,folder.label){mutableStateOf(folder.label)}
    AlertDialog(onDismissRequest=vm::cancelFolderRename,title={Text("Rename folder",color=text)},text={OutlinedTextField(value=name,onValueChange={name=it},singleLine=true,placeholder={Text("Folder name")})},confirmButton={TextButton(onClick={vm.renameFolder(folderId,name)}){Text("Save",color=accent)}},dismissButton={TextButton(onClick=vm::cancelFolderRename){Text("Cancel")}})
}

@Composable private fun AppDrawer(vm:LauncherViewModel,bg:Color,surface:Color,text:Color,muted:Color,accent:Color){
    BackHandlerCompat{vm.closeDrawer()}
    val scope=rememberCoroutineScope()
    val gridState=remember{LazyGridState()}
    val context=LocalContext.current
    val categories=listOf("All","Communication","Media","Tools","Games","Other")
    fun categoryOf(app:LauncherApp):String{
        val ai=try{context.packageManager.getApplicationInfo(app.packageName!!,0)}catch(_:Exception){null}
        return when(ai?.category){
            android.content.pm.ApplicationInfo.CATEGORY_GAME->"Games"
            android.content.pm.ApplicationInfo.CATEGORY_AUDIO,
            android.content.pm.ApplicationInfo.CATEGORY_VIDEO,
            android.content.pm.ApplicationInfo.CATEGORY_IMAGE->"Media"
            else->when{
                app.label.contains(Regex("phone|message|contact|mail|chat|whatsapp|telegram|discord",RegexOption.IGNORE_CASE))->"Communication"
                app.label.contains(Regex("calculator|clock|file|settings|calendar|drive|maps|weather",RegexOption.IGNORE_CASE))->"Tools"
                else->"Other"
            }
        }
    }
    val base=when(vm.drawerCategory){"All"->vm.installedApps;else->vm.installedApps.filter{categoryOf(it)==vm.drawerCategory}}
    val filtered=if(vm.appSearch.isBlank())base else base.filter{it.label.contains(vm.appSearch,true)}
    val recent=vm.recentAppIds.mapNotNull{id->vm.installedApps.firstOrNull{it.id==id}}.filter{filtered.any{x->x.id==it.id}}
    val alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val grouped=filtered.groupBy{it.label.firstOrNull()?.uppercaseChar() ?: '#'}
    Box(
        Modifier.fillMaxSize()
            .background(bg.copy(alpha=.97f))
            .pointerInput(Unit){detectVerticalDragGestures(onVerticalDrag={_,_ ->},onDragEnd={})},
        contentAlignment=Alignment.BottomCenter
    ){
        Surface(Modifier.fillMaxWidth().fillMaxHeight(.94f),shape=RoundedCornerShape(topStart=30.dp,topEnd=30.dp),color=surface,tonalElevation=10.dp){
            Column(Modifier.padding(horizontal=18.dp,vertical=14.dp)){
                Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center){Box(Modifier.width(42.dp).height(4.dp).background(muted.copy(alpha=.35f),RoundedCornerShape(3.dp)))}
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.weight(1f)){Text("Apps",color=text,fontSize=24.sp,fontWeight=FontWeight.SemiBold);Text("${filtered.size} apps",color=muted,fontSize=10.sp)}
                    Surface(onClick={vm::closeDrawer},shape=CircleShape,tonalElevation=2.dp){Text("×",Modifier.padding(horizontal=10.dp,vertical=4.dp),fontSize=20.sp)}
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value=vm.appSearch,onValueChange=vm::setSearch,modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search apps…",fontSize=12.sp)},shape=RoundedCornerShape(18.dp),leadingIcon={Text("⌕",fontSize=20.sp,color=muted)},trailingIcon={if(vm.appSearch.isNotEmpty())TextButton(onClick={ {vm.setSearch("")} }){Text("×",color=muted)}})
                Spacer(Modifier.height(9.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){categories.forEach{cat->Surface(onClick={vm.setDrawerCategory(cat)},shape=RoundedCornerShape(14.dp),color=if(vm.drawerCategory==cat)accent else surface,tonalElevation=if(vm.drawerCategory==cat)3.dp else 1.dp){Text(cat,color=if(vm.drawerCategory==cat)Color.White else text,fontSize=9.sp,modifier=Modifier.padding(horizontal=10.dp,vertical=7.dp))}}}
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
                    Text(if(vm.drawerCategory=="All")"Recently Used" else vm.drawerCategory,color=text,fontSize=13.sp,fontWeight=FontWeight.Medium,modifier=Modifier.weight(1f))
                    Surface(onClick={vm.setDrawerListMode(!vm.drawerListMode)},shape=RoundedCornerShape(14.dp),tonalElevation=1.dp){Text(if(vm.drawerListMode)"▦" else "☷",color=accent,fontSize=16.sp,modifier=Modifier.padding(horizontal=10.dp,vertical=6.dp))}
                }
                Spacer(Modifier.height(5.dp))
                if(vm.appSearch.isBlank() && vm.drawerCategory=="All" && recent.isNotEmpty()){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                        recent.take(4).forEach{app->Surface(onClick={vm.launchApp(context,app);vm.closeDrawer()},shape=RoundedCornerShape(16.dp),tonalElevation=1.dp,modifier=Modifier.weight(1f).height(72.dp)){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){AppIcon(app,Modifier.size(34.dp),accent);Text(app.label,color=text,fontSize=8.sp,maxLines=1)}}}
                    }
                    Spacer(Modifier.height(9.dp))
                }
                Box(Modifier.fillMaxSize()){
                    if(vm.drawerListMode){
                        androidx.compose.foundation.lazy.LazyColumn(contentPadding=PaddingValues(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxSize()){
                            filtered.forEach{app->item(key=app.id){Surface(onClick={vm.launchApp(context,app);vm.closeDrawer()},shape=RoundedCornerShape(16.dp),tonalElevation=1.dp,modifier=Modifier.fillMaxWidth().height(58.dp)){Row(Modifier.padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){AppIcon(app,Modifier.size(36.dp),accent);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(app.label,color=text,fontSize=11.sp,fontWeight=FontWeight.Medium);Text(app.packageName.orEmpty(),color=muted,fontSize=8.sp,maxLines=1)};Text("›",color=muted,fontSize=20.sp)}}}}
                        }
                    }else{
                        LazyVerticalGrid(state=gridState,columns=GridCells.Fixed(vm.gridMode.columns),contentPadding=PaddingValues(end=20.dp,bottom=24.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxSize()){
                            if(vm.appSearch.isBlank() && vm.drawerCategory=="All" && recent.isNotEmpty()) item(span={androidx.compose.foundation.lazy.grid.GridItemSpan(vm.gridMode.columns)}){Text("All Apps",color=muted,fontSize=10.sp,modifier=Modifier.padding(top=2.dp))}
                            items(filtered,key={it.id}){app->Surface(onClick={vm.launchApp(context,app);vm.closeDrawer()},shape=RoundedCornerShape(18.dp),tonalElevation=1.dp,modifier=Modifier.height(88.dp)){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){AppIcon(app,Modifier.size(42.dp),accent);Spacer(Modifier.height(4.dp));Text(app.label,color=text,fontSize=9.sp,maxLines=1)}}}
                        }
                        if(vm.appSearch.isBlank() && filtered.size>8){
                            Column(Modifier.align(Alignment.CenterEnd).padding(end=0.dp).width(18.dp).fillMaxHeight(),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){alpha.forEach{ch->Text(ch.toString(),color=if(grouped.containsKey(ch))accent.copy(alpha=.9f) else muted.copy(alpha=.35f),fontSize=7.sp,modifier=Modifier.clickableWithoutRipple{val idx=filtered.indexOfFirst{it.label.firstOrNull()?.uppercaseChar()==ch};if(idx>=0)scope.launch{gridState.animateScrollToItem(idx)}})}}
                        }
                    }
                }
            }
        }
    }
}
@Composable private fun BackHandlerCompat(onBack:()->Unit){androidx.activity.compose.BackHandler(enabled=true,onBack=onBack)}

private fun Modifier.clickableWithoutRipple(onClick:()->Unit)=composedClickable(onClick)
@Composable private fun composedClickable(onClick:()->Unit):Modifier{val interaction=remember{androidx.compose.foundation.interaction.MutableInteractionSource()};return Modifier.then(Modifier.clickable(interactionSource=interaction,indication=null,onClick=onClick))}
